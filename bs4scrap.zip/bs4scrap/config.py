# config.py

BASE_URL = "https://webscraper.io/test-sites/e-commerce/ajax/computers/laptops"

PAGE_LOAD_WAIT = 10   # Temps d’attente pour chargement AJAX
